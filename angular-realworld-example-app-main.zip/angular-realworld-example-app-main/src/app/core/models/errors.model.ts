export interface Errors {
  errors: { [key: string]: string };
}
